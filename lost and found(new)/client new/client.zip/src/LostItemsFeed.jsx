import React, { useEffect, useState } from 'react';
import axios from 'axios';

function LostItemsFeed() {
  const [lostItems, setLostItems] = useState([]);

  useEffect(() => {
    // Fetch lost items data from backend
    const fetchLostItems = async () => {
      try {
        const response = await axios.get('http://localhost:3001/api/lostItems');
        setLostItems(response.data);
      } catch (error) {
        console.error('Error fetching lost items:', error);
      }
    };

    fetchLostItems();
  }, []);

  return (
    <div className="max-w-4xl mx-auto mt-8">
      <h1 className="text-2xl font-semibold mb-4">Lost Items Feed</h1>
      {lostItems.map((item) => (
        <div key={item.id} className="bg-white rounded-lg shadow-md p-4 mb-4">
          <h2 className="text-lg font-semibold">{item.itemName}</h2>
          <p className="text-gray-600">{item.location}</p>
          <p className="text-gray-600">{item.timeLost}</p>
          <p className="text-gray-600">{item.category}</p>
          <div>
              <p>By: <span className='text-gray-500 text-sm underline'>@{item.userId?.username}</span></p>
            </div>
        </div>
      ))}
    </div>
  );
}

export default LostItemsFeed;
